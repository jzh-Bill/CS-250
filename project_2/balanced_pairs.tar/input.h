#define MAX 200

FILE *open_file(char *file);
char *pull_out_string(FILE *f);
char input_function(char first_pair_left, char first_pair_right, char second_pair_left, char second_right_pair,char cstring[]);
